
const BASE_URL = import.meta.env.VITE_API_URL;

// src/api/problems.ts
export interface Problem {
    id: number,
    level: 1 | 2 | 3 | 4 | 5
    type: 1 | 2,
    problemImageUrl: string,
    title: string,
    answerRate: number
}

export const fetchProblems = async (): Promise<Problem[]> => {
    const res = await fetch(`${BASE_URL}/problems`);

    if (!res.ok) {
        throw new Error("문제 목록을 불러오는데 실패했습니다");
    }

    return res.json(); // JSON 자동 파싱
};


export const fetchSimimarProblems = async (problemId: number, excludedProblemIds: Array<number>): Promise<Problem[]> => {

    const params = new URLSearchParams()
    params.set("excludedProblemIds", excludedProblemIds.join(','))

    const res = await fetch(`${BASE_URL}/problems/${problemId}/similarity?${params.toString()}`);

    if (!res.ok) {
        throw new Error("문제 목록을 불러오는데 실패했습니다");
    }

    return res.json(); // JSON 자동 파싱
};
