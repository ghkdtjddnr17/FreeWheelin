import { useEffect } from "react"
import { useSimilarProblems } from "../../hooks/useProblems"
import { useProblemStore } from "../../store/useProbleamStore"
import ProblemCard from "../common/ProblemCard"
import { useProblemActions } from "../../hooks/useProblemActions"


const SimilarProblemPanel = () => {

    const { data } = useSimilarProblems()
    const similarProblems = useProblemStore(state => state.similarProblems);
    const { swap, insert, setSimilarProblems } = useProblemActions();

    useEffect(() => {
        if (data) setSimilarProblems(data)
    }, [data])

    console.log(similarProblems);

    return (
        <div className="min-w-[504px] h-full bg-gray-100 rounded-xl p-6">
            <div className="text-base font-bold mb-6">유사 문항</div>
            {
                similarProblems.length > 0 ? <div className="flex flex-col h-full">
                    <div className="w-full overflow-y-auto overflow-x-hidden box-border">

                        {
                            similarProblems.map((item, i) => {
                                return <ProblemCard
                                    key={item.id}
                                    problemItem={item}
                                    index={i + 1}
                                    selected={false}
                                    primaryAction={{
                                        label: "교체",
                                        icon: "ic_swap",
                                        onClick: () => swap(item.id)
                                    }}
                                    secondaryAction={{
                                        label: "추가",
                                        icon: "ic_plus",
                                        onClick: () => insert(item.id)
                                    }} />
                            })
                        }
                    </div>
                </div> :
                    <div className="text-center text-gray-500 text-sm space-y-1 flex flex-col justify-center h-full">
                        <div className="flex items-center justify-center gap-1">
                            <div className="text-xs border border-gray-300 rounded-full px-2 py-0.5">
                                유사문제
                            </div>
                            <span>버튼을 누르면</span>
                        </div>
                        <div>문제를 추가 또는 교체할 수 있습니다.</div>
                    </div>
            }
        </div>

    )
}

export default SimilarProblemPanel