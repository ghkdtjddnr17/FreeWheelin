import React, { useEffect, useRef, useState } from "react";

export function CustomScrollbar({ height = 300, children }: { height?: number, children: React.ReactNode }) {
    const [showBar, setShowBar] = useState(false);
    const [barTop, setBarTop] = useState(0);
    const [barHeight, setBarHeight] = useState(0);
    const timerRef = useRef<NodeJS.Timeout | null>(null);
    const containerRef = useRef<HTMLDivElement>(null);

    // 상태: 실제로는 "visible" + "fade out중" 두 단계 필요
    const [isVisible, setIsVisible] = useState(false);

    const handleScroll = () => {
        setShowBar(true);
        setIsVisible(true); // 스크롤하면 bar는 바로 보이게
        if (timerRef.current) clearTimeout(timerRef.current);

        // thumb 계산 (생략 가능)
        const el = containerRef.current;
        if (el) {
            const ratio = el.scrollTop / (el.scrollHeight - el.clientHeight);
            const scrollBarHeight = Math.max(20, (el.clientHeight / el.scrollHeight) * el.clientHeight);
            setBarHeight(scrollBarHeight);
            setBarTop(ratio * (el.clientHeight - scrollBarHeight));
        }

        timerRef.current = setTimeout(() => {
            setShowBar(false); // 내부 표시값 먼저 false
            setTimeout(() => setIsVisible(false), 400); // 0.4초 뒤 아예 제거
        }, 1000);
    };

    // 최초 사이즈 대응
    useEffect(() => {
        const el = containerRef.current;
        if (el) {
            const scrollBarHeight = Math.max(20, (el.clientHeight / el.scrollHeight) * el.clientHeight);
            setBarHeight(scrollBarHeight);
            setBarTop(0);
        }
    }, []);

    return (
        <div className="relative" style={{ height }}>
            <div
                ref={containerRef}
                className="h-full overflow-y-scroll pr-2"
                style={{ scrollbarWidth: "none" }}
                onScroll={handleScroll}
            >
                <style>{`
          div::-webkit-scrollbar { display: none; }
        `}</style>
                {children}
            </div>
            {/* 바가 showBar일 때만 opacity 1, 아니면 0 (isVisible이 true면 div는 남아있음) */}
            {isVisible && (
                <div
                    className="absolute right-1 bg-gray-400 rounded pointer-events-none transition-opacity duration-400"
                    style={{
                        width: 6,
                        top: barTop,
                        height: barHeight,
                        opacity: showBar ? 1 : 0, // 트랜지션
                    }}
                />
            )}
        </div>
    );
}
