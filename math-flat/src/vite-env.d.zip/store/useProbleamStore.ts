import { create } from 'zustand'
import type { Problem } from '../api/Problems'


interface ProblemStore {
    problems: Array<Problem>
    similarProblems: Array<Problem>
    activeId: number
    setProblems: (problems: Problem[]) => void
    setSimilarProblems: (similarProblems: Problem[]) => void
    setId: (id: number) => void
    removeProblem: (problemInfo: Problem) => void
    swapProblem: (worksheetId: number, similarId: number) => void;
    insertProblemBeforeActive: (similarId: number) => void
    fetchTriggerId: number;  // 유사문제 fetch 트리거 용
    setFetchTriggerId: (id: number) => void;
}


export const useProblemStore = create<ProblemStore>((set) => ({
    activeId: 0,
    problems: [],
    similarProblems: [],
    setId: (problemId: number) => set(() => ({ activeId: problemId })),
    setProblems: problems => set({ problems }),
    setSimilarProblems: similarProblems => set({ similarProblems }),
    removeProblem: problemInfo => set(state => {
        const isActive = state.activeId === problemInfo.id;
        return {
            problems: state.problems.filter(p => p.id !== problemInfo.id),
            similarProblems: isActive ? [] : state.similarProblems,
            activeId: isActive ? 0 : state.activeId

        }
    }),
    swapProblem: (worksheetId, similarId) => set(state => {
        // 1. 인덱스 찾기
        const worksheetIdx = state.problems.findIndex(p => p.id === worksheetId);
        const similarIdx = state.similarProblems.findIndex(p => p.id === similarId);
        if (worksheetIdx === -1 || similarIdx === -1) return state;

        // 2. 두 문제 swap
        const newProblems = [...state.problems];
        const newSimilar = [...state.similarProblems];
        // swap!
        const tmp = newProblems[worksheetIdx];
        newProblems[worksheetIdx] = newSimilar[similarIdx];
        newSimilar[similarIdx] = tmp;

        return {
            problems: newProblems,
            similarProblems: newSimilar,
            activeId: newProblems[worksheetIdx].id, // 교체된(=새로 들어온) id로 active 상태 변경
        };
    }),
    insertProblemBeforeActive: (similarId: number) =>
        set(state => {
            // 1. active 문제 인덱스 찾기
            const activeIdx = state.problems.findIndex(p => p.id === state.activeId);
            if (activeIdx === -1) return state;

            // 2. similarProblems에서 해당 문제 찾기
            const similarIdx = state.similarProblems.findIndex(p => p.id === similarId);
            if (similarIdx === -1) return state;

            const insertProblem = state.similarProblems[similarIdx];

            // 3. problems에서 activeIdx 바로 앞에 insert
            const newProblems = [...state.problems];
            newProblems.splice(activeIdx + 1, 0, insertProblem);

            // 4. similarProblems에서 삭제
            const newSimilarProblems = state.similarProblems.filter(p => p.id !== similarId);
            console.log({ newSimilarProblems });

            // 5. 상태 업데이트
            return {
                problems: newProblems,
                similarProblems: newSimilarProblems,
                // activeId: insertProblem.id, // 추가된 문제로 activeId 바꿀지 여부는 상황 따라 선택
            };
        }),
    fetchTriggerId: 0,
    setFetchTriggerId: (id) => set({ fetchTriggerId: id }),

})) 